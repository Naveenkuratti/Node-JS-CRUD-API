// // const express = require('express');

// // const app = express();
// // app.use(express.json());

// // app.get('/',(req,res)=>{
// //     res.send('Hello World, my name is Naveen  kuratti');
// // })
// // app.listen(5000,()=>{
// //     console.log('Server is running on port 5000');
// // })

// // app.get('/products/:id',(req,res)=>{
// //     console.log(req.params.id);

// //     const {id }=req.params;
// //    res.json({message:'this is products',product:req.params.id});
// // })
// // //Post Route
// // app.post('/products',(req,res)=>{
// //    const {name,price}=req.body;
// //    res.json({message:'This is the products Post Route page',
// //     name:name,
// //     price:price
// //    });

// // console.log(req.body);

// // })

// // //PUT Route
// // app.put('/products',(req,res)=>{
// //     res.send('This is the products  Put Route page');
// // })

// // //Delete Route
// // app.delete('/products',(req,res)=>{
// //     res.send('This is the products  Delete Route page');
// // })
// // app.get('/products',(req,res)=>{
// //     res.send( 'This is the products page');
// // })

// import express from "express";
// import connectDB from "./config/db.js";
// import contactRoutes from "./routes/contactRoutes.js";

// const app = express();

// // middleware
// app.use(express.json());

// // DB
// connectDB();

// app.get("/", (req, res) => {
//   res.json({ message: "contact manager api" });
// });

// // routes
// app.use("/contacts", contactRoutes);

// app.listen(5000, () => {
//   console.log("Server is running on port 5000");
// });
import express from "express";
import connectDB from "./config/db.js";
import contactRoutes from "./routes/contactRoutes.js";

const app = express();

// middleware
app.use(express.json());

// connect database
connectDB();

app.get("/", (req, res) => {
  res.json({ message: "contact manager api" });
});

// routes
app.use("/contacts", contactRoutes);

app.listen(5000, () => {
  console.log("Server is running on port 5000");
});
